clc;
clear;

% Parameters
N = 1000;                    % Number of samples
fs = 1000;                   % Sampling frequency
f = 5;                       % Frequency of sine wave
mu = 0.0007;                 % Step size for LMS
M = 128;                     % Filter length
MSEth = 0.015;               % Threshold for declaring noise removal

% Signals
t = (0:N-1)/fs;
desired = sin(2*pi*f*t);                   % Clean sine wave (desired)
noise = 0.5*randn(1, N);                   % Additive white Gaussian noise
x = desired + noise;                       % Noisy input

% Padding
x_padded = [zeros(1, M-1), x];             % Zero padding for early filtering

% Use a known FIR filter to produce target signal (simulate channel)
fir_coeffs = fir1(M-1, 0.2);               % FIR low-pass filter
d = filter(fir_coeffs, 1, x);              % Output from unknown system

% LMS Initialization
w = zeros(1, M);                           % Filter weights
y = zeros(1, N);                           % LMS output
e = zeros(1, N);                           % Error signal
MSE = zeros(1, N);                         % MSE tracker

% Adaptive Filtering
for n = 1:N
    x_vec = x_padded(n+M-1:-1:n);          % Get M samples from padded input
    y(n) = w * x_vec';                     % Filter output
    e(n) = desired(n) - y(n);              % Error
    w = w + 2 * mu * e(n) * x_vec;         % Weight update (LMS)
    MSE(n) = mean(e(max(1,n-99):n).^2);    % MSE over last 100 samples
    fprintf('Iteration %d - MSE: %.6f\n', n, MSE(n));
end

% Convergence Check
final_MSE = MSE(end);
if final_MSE < MSEth
    fprintf('\nNoise removed \n');
else
    fprintf('\nNoise present \n');
end

% Plot 1: Error vs Iteration
figure;
plot(e.^2);
xlabel('Iteration');
ylabel('Squared Error');
title('Error vs Iteration');

% Plot 2: Noise Cancellation Result
figure;
plot(t, desired, 'g', 'DisplayName', 'Clean Signal');
hold on;
plot(t, x, 'r--', 'DisplayName', 'Noisy Input');
plot(t, y, 'b', 'DisplayName', 'LMS Output');
legend;
xlabel('Time (s)');
ylabel('Amplitude');
title('Noise Cancellation Result');

% Confusion Matrix
TP = sum(abs(desired - y) < 0.065 & abs(x - desired) > 0.065);
FP = sum(abs(desired - y) < 0.065 & abs(x - desired) < 0.065);
TN = sum(abs(desired - y) > 0.065 & abs(x - desired) > 0.065);
FN = sum(abs(desired - y) > 0.065 & abs(x - desired) < 0.065);

fprintf('\nConfusion Matrix:\n');
fprintf('TP: %d (Correct detection of noise removal)\n', TP);
fprintf('FP: %d (Noisy output classified as clean)\n', FP);
fprintf('TN: %d (Noise correctly detected)\n', TN);
fprintf('FN: %d (Clean signal missed)\n', FN);

% Save Confusion Matrix to Excel (append mode)
confusionData = {
    'Confusion Matrix', '', '';
    '', 'Predicted Clean', 'Predicted Noisy';
    'Actual Clean',  TP,           FN;
    'Actual Noisy',  FP,           TN;
    '', '', '';
    'Timestamp:', datestr(now), ''
};

% Excel filename
filename = 'LMS.xlsx';

% Check if file exists
if isfile(filename)
    existingData = readcell(filename);
    [rows, ~] = size(existingData);
    startRow = rows + 3; % Leave 2 blank rows
else
    startRow = 1;
end

% Write confusion matrix
writecell(confusionData, filename, 'Range', ['A' num2str(startRow)]);

fprintf('\nConfusion matrix appended to Excel file: %s\n', filename);

% MSE Calculations
MSE_before = mean((desired - x).^2);
MSE_after  = mean((desired - y).^2);

fprintf('\nMSE before filtering (noisy vs desired): %.6f\n', MSE_before);
fprintf('MSE after filtering  (LMS output vs desired): %.6f\n', MSE_after);

% Visual comparison
figure;
plot(abs(desired - x), 'r--', 'DisplayName', 'Error before filtering');
hold on;
plot(abs(desired - y), 'b', 'DisplayName', 'Error after filtering');
legend;
xlabel('Sample');
ylabel('Absolute Error');
title('Error Before vs After Filtering');
